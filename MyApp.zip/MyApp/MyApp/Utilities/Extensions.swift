
import Foundation
import SwiftyJSON

extension UITableView {
    func setBottomEdgeInset(val: CGFloat) {
        self.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: val, right: 0)
    }
    
    func showNodataLabelWithText(text:String!, posY: CGFloat? = nil) {
        hideNoDataLabel()
        let label = UILabel()
        label.frame = CGRect(x: 0, y: 0, width: self.frame.width, height: 40)
        label.text = text ?? "No data found"
        label.tag = 111
        label.textColor = UIColor.color(r: 79, g: 96, b: 112)
        label.textAlignment = .center
        label.numberOfLines = 0
        label.sizeToFit()
        let positionY = posY != nil ? posY! : self.frame.height/2.0
        label.center = CGPoint(x: self.frame.width/2.0, y: positionY)
        self.addSubview(label)
    }
    
    func hideNoDataLabel() {
        for _views in self.subviews as [UIView] {
            if let labelView = _views as? UILabel {
                if labelView.tag == 111 {
                    labelView.isHidden = true
                    labelView.removeFromSuperview()
                    break
                }
            }
        }
    }
}

extension UIColor {
    static func color(r: Int, g: Int, b: Int) -> UIColor {
        return UIColor(red: CGFloat(r)/255.0, green: CGFloat(g)/255.0, blue: CGFloat(b)/255.0, alpha: 1)
    }
    
    static func color(r: Int, g: Int, b: Int, a: Float) -> UIColor {
        return UIColor(red: CGFloat(r)/255.0, green: CGFloat(g)/255.0, blue: CGFloat(b)/255.0, alpha: CGFloat(a))
    }
    
}

