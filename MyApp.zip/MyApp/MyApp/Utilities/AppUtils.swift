//
//  AppUtils.swift
//  OkTalk
//
//  Created by Adarsh on 14/08/17.
//  Copyright © 2017 OKTalk.com. All rights reserved.
//

import UIKit
import SafariServices

class AppUtils: NSObject {

    static let sharedUtil = AppUtils()
    
    //MARK: - Instance functions
    func openSafariVC(_ URLString:String, onController vc: UIViewController)
    {
        let svc = SFSafariViewController(url: URL(string: URLString)!)
        svc.delegate = self
        vc.present(svc, animated: true, completion: {
            UIApplication.shared.statusBarStyle = .lightContent
        })
    }
}

extension AppUtils: SFSafariViewControllerDelegate{
    func safariViewControllerDidFinish(_ controller: SFSafariViewController) {
        controller.dismiss(animated: true, completion: nil)
    }
}
