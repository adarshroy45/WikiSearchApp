//
//  AppConstants.swift
//  MovieApp
//
//  Created by Adarsh on 05/02/18.
//  Copyright © 2018 IOS. All rights reserved.
//

import Foundation
import UIKit

let appdelegate = UIApplication.shared.delegate as! AppDelegate
let managedObjContext = appdelegate.persistentContainer.viewContext

let NO_RESULTS_FOUND = "No results found"
let TEST_LINK = "https://en.wikipedia.org/wiki/Interstellar_(film)"


