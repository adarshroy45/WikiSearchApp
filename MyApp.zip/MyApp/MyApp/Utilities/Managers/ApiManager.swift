//
//  ApiManager.swift
//  MovieApp
//
//  Created by Adarsh on 05/02/18.
//  Copyright © 2018 IOS. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON

class ApiManager {
    static let sharedInstance = ApiManager()
    let configuration = URLSessionConfiguration.default
    
    let sessionManager:SessionManager!
    
    init() {
        configuration.timeoutIntervalForRequest = 60
        sessionManager = Alamofire.SessionManager(configuration: configuration)
    }
    
    //MARK: - Fetch Items
    func fetchSearchItems(searchText: String, successBlock: @escaping ((JSON) -> Void), failureBlock: ((String) -> Void)?){
        
        var encodedSearchText = searchText
        if let encode = encodedSearchText.addingPercentEncoding(withAllowedCharacters:NSCharacterSet.urlQueryAllowed){
            encodedSearchText = encode
        }
        
        //Request URL: "https://en.wikipedia.org//w/api.php?action=query&format=json&prop=pageimages%7Cpageterms&generator=prefixsearch&redirects=1&formatversion=2&piprop=thumbnail&pithumbsize=50&pilimit=10&wbptterms=description&gpssearch=Sachin+T&gpslimit=10"
        
        //api (which fetches url): https://en.wikipedia.org//w/api.php?action=query&format=json&prop=pageimages|pageterms|info&inprop=url&generator=prefixsearch&redirects=1&formatversion=2&piprop=thumbnail&pithumbsize=50&pilimit=10&wbptterms=description&gpssearch=Sachin%20T&gpslimit=10

        let propVal = "pageimages|pageterms|info".addingPercentEncoding(withAllowedCharacters:NSCharacterSet.urlQueryAllowed)!
        let requestURL = "https://en.wikipedia.org//w/api.php?action=query&format=json&prop=\(propVal)&inprop=url&generator=prefixsearch&redirects=1&formatversion=2&piprop=thumbnail&pithumbsize=50&pilimit=10&wbptterms=description&gpssearch=\(encodedSearchText)&gpslimit=50"
        debugPrint(requestURL)
        sessionManager.request(requestURL, method: .get, encoding: JSONEncoding.default, headers: nil).responseJSON {(responseData) -> Void in
            
            if responseData.result.value != nil{
                let responseJSON = JSON(responseData.result.value!)
                if responseData.response?.statusCode == 200{
                    if responseJSON != JSON.null{
                        successBlock(responseJSON)
                    }
                }
                else {
                    if let fb = failureBlock {
                        fb(NSLocalizedString("ERROR_MESSAGE", comment: responseJSON["status"].stringValue))
                    }
                }
            }
            else{
                if let fb = failureBlock {
                    fb(NSLocalizedString("ERROR_MESSAGE", comment: "Unable to get json response"))
                }
            }
        }
    }
}
