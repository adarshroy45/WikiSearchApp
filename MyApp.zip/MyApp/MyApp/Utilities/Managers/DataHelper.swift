

import Foundation
import CoreData
import SwiftyJSON

class DataHelper: NSObject {
    
    static let sharedInstance = DataHelper()
    
    fileprivate override init() { }
    
    func executeFetchRequest(request:NSFetchRequest<NSFetchRequestResult>) -> [NSManagedObject]{
        var fetchedMessages: [NSManagedObject]? = nil
        do{
            fetchedMessages = try managedObjContext.fetch(request) as? [NSManagedObject]
        } catch {
            debugPrint("Failure in executeFetchRequest: \(error)")
        }
        return fetchedMessages!
    }
    
    //Save
    fileprivate func saveContext() {
        do {
            try managedObjContext.save()
        } catch {
            let nserror = error as NSError
            fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
        }
    }
    
    //MARK: Insert/Update
    
    func insertOrUpdateItem(itemID: String, itemName: String, itemDesc: String, itemImgURL: String, itemLink: String) {
        let trimdItemName = itemName.replacingOccurrences(of: "\'", with: " ")
        let fetchRequest:NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: "Item")
        fetchRequest.predicate = NSPredicate(format: "itemName == '\(trimdItemName)'")
        
        let fetchedObjects = self.executeFetchRequest(request: fetchRequest) as! [Item]
        let obj: Item!
        if !fetchedObjects.isEmpty {
            obj = fetchedObjects.last!
        } else {
            obj = NSEntityDescription.insertNewObject(forEntityName: "Item", into: managedObjContext) as? Item
        }
        
        //Now set the values
        obj.itemID = itemID
        obj.itemName = trimdItemName
        obj.itemDesc = itemDesc
        obj.itemImgURL = itemImgURL
        obj.itemLink = itemLink
        
        saveContext()
    }
    
    //MARK: Fetch
    func fetchAllItems() -> [Item] {
        let fetchRequest:NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: "Item")
        let fetchedObjects = self.executeFetchRequest(request: fetchRequest) as! [Item]
        return fetchedObjects
    }
    
    func fetchItems(searchText: String) -> [Item] {
        let fetchRequest:NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: "Item")
        fetchRequest.predicate = NSPredicate(format: "itemName contains[cd] '\(searchText)'")
        let fetchedObjects = self.executeFetchRequest(request: fetchRequest) as! [Item]
        return fetchedObjects
    }
    
    func fetchAllRecords(tableName: String) -> [NSManagedObject] {
        let fetchRequest:NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: tableName)
        let fetchedObjects = self.executeFetchRequest(request: fetchRequest)
        return fetchedObjects
    }
    
    //MARK: Delete
    
    func removeAllRecords(tableName: String) {
        let fetch = NSFetchRequest<NSFetchRequestResult>(entityName: tableName)
        let request = NSBatchDeleteRequest(fetchRequest: fetch)
        do {
            try managedObjContext.execute(request)
            try managedObjContext.save()
        } catch {
            fatalError("There was an error")
        }
    }
 
    func flushTables(tableNames: [String]) {
        for tableName in tableNames {
            self.removeAllRecords(tableName: tableName)
        }
    }
    
     func flushAllTables() {
        flushTables(tableNames: ["Facility","Option","Exclusion","ExBasic"])
    }
    
}
