//
//  ItemCell.swift
//  MyApp
//
//  Created by Adarsh on 24/06/18.
//  Copyright © 2018 IOS. All rights reserved.
//

import UIKit
import AlamofireImage

class ItemCell: UITableViewCell {
    
    @IBOutlet weak var imageViewPic: UIImageView!
    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var labelDescription: UILabel!
    
    
    var itemEntity: Item! {
        didSet {
            labelTitle.text = itemEntity.itemName
            labelDescription.text = itemEntity.itemDesc
            imageViewPic.image = #imageLiteral(resourceName: "icon_placeholder")
            if itemEntity.itemImgURL != nil, let urlImg = URL(string: itemEntity.itemImgURL!)   {
                imageViewPic.af_setImage(withURL: urlImg)
            }
        }
    }

}
