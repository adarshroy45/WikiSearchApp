//
//  MyApp
//
//  Created by Adarsh on 21/06/18.
//  Copyright © 2018 IOS. All rights reserved.
//

import UIKit
import SwiftyJSON
import ReachabilitySwift

class SearchViewController: UIViewController {
    
    @IBOutlet weak var tableViewSearch: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    var arrSearchItem: [Item]!
    var strSearchText:String = "" {
        didSet {
            NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(reloadSearchTable), object: nil)
            self.perform(#selector(reloadSearchTable), with: nil, afterDelay: 1.0)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    func setupUI() {
        self.activityIndicator.isHidden = true
        self.tableViewSearch.isHidden = true
        self.tableViewSearch.tableFooterView = UIView()
        self.tableViewSearch.setBottomEdgeInset(val: 0)
        self.tableViewSearch.rowHeight = UITableViewAutomaticDimension
        self.tableViewSearch.estimatedRowHeight = 70
    }
    
    @objc func reloadSearchTable(){
        if strSearchText == ""{
            if self.arrSearchItem.count>0 {
                self.arrSearchItem.removeAll()
            }
            self.tableViewSearch.reloadData()
            self.tableViewSearch.isHidden = true
        }else{
            callSearchItemApi(searchText: strSearchText)
        }
    }
    
    func fetchFromLocalDB(searchText: String) {
        self.arrSearchItem = DataHelper.sharedInstance.fetchItems(searchText: searchText)
        self.activityIndicator.isHidden = true
        guard searchText == self.strSearchText else {return} //this don't allows further process (like reload-table) after fetching long-loading api-response of older searchText.
        self.tableViewSearch.isHidden = false // tableView needs to unhide, as it was hidden when searchbar had no-text
        self.tableViewSearch.reloadData()
        (self.arrSearchItem.count > 0) ? self.tableViewSearch.hideNoDataLabel() : self.tableViewSearch.showNodataLabelWithText(text: NO_RESULTS_FOUND, posY: self.tableViewSearch.frame.height*0.25)
    }
    
    //MARK: - API Section
    func callSearchItemApi(searchText: String){
        self.activityIndicator.isHidden = false
        guard Reachability()?.isReachable == true else {
            fetchFromLocalDB(searchText: searchText)
            return
        }
        ApiManager.sharedInstance.fetchSearchItems(searchText: searchText ,successBlock: { (response) in
            self.successTaskSearchItemApi(response: response, searchText: searchText)

        }, failureBlock: { (desc) in
            self.activityIndicator.isHidden = true
        })
    }
    
    func successTaskSearchItemApi(response: JSON, searchText: String) {
        debugPrint(response)
        for dictItem in response["query"]["pages"].arrayValue {
            DataHelper.sharedInstance.insertOrUpdateItem(itemID: dictItem["pageid"].stringValue, itemName: dictItem["title"].stringValue, itemDesc: dictItem["terms"]["description"].arrayValue.first?.string ?? "No description", itemImgURL: dictItem["thumbnail"]["source"].stringValue, itemLink: dictItem["fullurl"].stringValue)
        }
        fetchFromLocalDB(searchText: searchText)
    }
}

extension SearchViewController: UISearchBarDelegate{
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        debugPrint(">>>>search text = \(searchText)")
        strSearchText = searchText
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        //keyboard task
        self.tableViewSearch.setBottomEdgeInset(val: 220)
        //--
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        strSearchText = searchBar.text!
        //keyboard task
        self.tableViewSearch.setBottomEdgeInset(val: 0)
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) { //keyboard 'search' btn clicked (keyboard 'return' btn, in other words )
        searchBar.resignFirstResponder()
    }
}

extension SearchViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let itemEntity = arrSearchItem[indexPath.row]
        if let itemLink = itemEntity.itemLink {
            AppUtils.sharedUtil.openSafariVC(itemLink, onController: self)
        }
    }
}

extension SearchViewController: UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrSearchItem != nil ? arrSearchItem.count : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ItemCell") as! ItemCell
        cell.itemEntity = arrSearchItem[indexPath.row]
        return cell
    }
}


