//
//  Item+CoreDataProperties.swift
//  
//
//  Created by Adarsh on 28/08/18.
//
//

import Foundation
import CoreData


extension Item {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Item> {
        return NSFetchRequest<Item>(entityName: "Item")
    }

    @NSManaged public var itemDesc: String?
    @NSManaged public var itemID: String?
    @NSManaged public var itemImgURL: String?
    @NSManaged public var itemName: String?
    @NSManaged public var itemLink: String?

}
