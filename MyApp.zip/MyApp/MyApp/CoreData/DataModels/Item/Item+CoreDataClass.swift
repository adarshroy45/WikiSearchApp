//
//  Item+CoreDataClass.swift
//  
//
//  Created by Adarsh on 28/08/18.
//
//

import Foundation
import CoreData

@objc(Item)
public class Item: NSManagedObject {

}
